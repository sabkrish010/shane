<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>tst_invalidMfaCode</name>
   <tag></tag>
   <elementGuidId>fb733b22-bb03-4c50-9423-d67b07df8e8e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[(text() = 'Invalid code
                        ' or . = 'Invalid code
                        ')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>1c63aa8b-66d3-47de-81c7-c7e8f89b2a97</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>toast-header bg-danger text-white</value>
      <webElementGuid>a519fd9c-e663-4090-8c45-50ca4737d707</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Invalid code
                        </value>
      <webElementGuid>c86923d7-a1dc-4b02-b264-3c7204630aa0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/div[1]/div[@class=&quot;toast-container position-absolute top-0 end-0 mt-5 pt-5 pe-2&quot;]/div[@class=&quot;d-flex top-0 translate-middle-x&quot;]/div[@class=&quot;toast show&quot;]/div[@class=&quot;toast-header bg-danger text-white&quot;]</value>
      <webElementGuid>f44740d9-8b73-494c-bd65-c7cccf4304e5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Invalid code
                        ' or . = 'Invalid code
                        ')]</value>
      <webElementGuid>8a054ae4-a02e-4d54-a5a4-03a83c5db294</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
