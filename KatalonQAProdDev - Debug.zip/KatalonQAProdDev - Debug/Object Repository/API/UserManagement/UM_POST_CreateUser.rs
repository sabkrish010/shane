<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description></description>
   <name>UM_POST_CreateUser</name>
   <tag></tag>
   <elementGuidId>7eff9415-120a-4763-83d5-6f1573e1d5cb</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
   <authorizationRequest>
      <authorizationInfo>
         <entry>
            <key>bearerToken</key>
            <value>${GlobalVariable.API_TOKEN}</value>
         </entry>
      </authorizationInfo>
      <authorizationType>Bearer</authorizationType>
   </authorizationRequest>
   <autoUpdateContent>false</autoUpdateContent>
   <connectionTimeout>0</connectionTimeout>
   <followRedirects>false</followRedirects>
   <httpBody></httpBody>
   <httpBodyContent>{
  &quot;text&quot;: &quot;{\n  \&quot;email\&quot;: \&quot;${email}\&quot;,\n  \&quot;phone\&quot;: \&quot;${phone}\&quot;,\n  \&quot;firstName\&quot;: \&quot;${firstName}\&quot;,\n  \&quot;lastName\&quot;: \&quot;${lastName}\&quot;,\n  \&quot;company\&quot;: \&quot;${company}\&quot;,\n  \&quot;jobTitle\&quot;: \&quot;${jobTitle}\&quot;,\n  \&quot;language\&quot;: \&quot;${language}\&quot;,\n  \&quot;effectiveDate\&quot;: \&quot;${effectiveDate}T10:50:16.584Z\&quot;,\n  \&quot;timeZone\&quot;: \&quot;${timezone}\&quot;\n}&quot;,
  &quot;contentType&quot;: &quot;application/json&quot;,
  &quot;charset&quot;: &quot;UTF-8&quot;
}</httpBodyContent>
   <httpBodyType>text</httpBodyType>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Content-Type</name>
      <type>Main</type>
      <value>application/json</value>
      <webElementGuid>6b4bdcfb-2f20-406d-8e24-9e88bd32e4c0</webElementGuid>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Authorization</name>
      <type>Main</type>
      <value>Bearer ${GlobalVariable.API_TOKEN}</value>
      <webElementGuid>fbe03491-bf7e-40d2-a51f-dfbd907d67d4</webElementGuid>
   </httpHeaderProperties>
   <katalonVersion>9.2.0</katalonVersion>
   <maxResponseSize>0</maxResponseSize>
   <migratedVersion>5.4.1</migratedVersion>
   <restRequestMethod>POST</restRequestMethod>
   <restUrl>${GlobalVariable.API_LIT}/users</restUrl>
   <serviceType>RESTful</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod></soapRequestMethod>
   <soapServiceEndpoint></soapServiceEndpoint>
   <soapServiceFunction></soapServiceFunction>
   <socketTimeout>0</socketTimeout>
   <useServiceInfoFromWsdl>true</useServiceInfoFromWsdl>
   <variables>
      <defaultValue>''</defaultValue>
      <description></description>
      <id>e4e07026-cef6-49be-914a-3b39f01d24e6</id>
      <masked>false</masked>
      <name>email</name>
   </variables>
   <variables>
      <defaultValue>''</defaultValue>
      <description></description>
      <id>89cb1e07-978e-4a3d-8647-c338fb813663</id>
      <masked>false</masked>
      <name>phone</name>
   </variables>
   <variables>
      <defaultValue>''</defaultValue>
      <description></description>
      <id>b62bfe24-acbc-4bc6-98b1-acc46a25b7fd</id>
      <masked>false</masked>
      <name>firstName</name>
   </variables>
   <variables>
      <defaultValue>''</defaultValue>
      <description></description>
      <id>2f61346f-e065-40e0-890d-96be66bba14f</id>
      <masked>false</masked>
      <name>lastName</name>
   </variables>
   <variables>
      <defaultValue>''</defaultValue>
      <description></description>
      <id>abe1b691-d9e3-4c11-9c57-8720fc002258</id>
      <masked>false</masked>
      <name>company</name>
   </variables>
   <variables>
      <defaultValue>''</defaultValue>
      <description></description>
      <id>83bcea79-82b2-4bb4-8078-47981fa0628a</id>
      <masked>false</masked>
      <name>jobTitle</name>
   </variables>
   <variables>
      <defaultValue>GlobalVariable.EFFECTIVE_DATE</defaultValue>
      <description></description>
      <id>927e0573-372a-4607-905b-4d1a9fa4d3b4</id>
      <masked>false</masked>
      <name>effectiveDate</name>
   </variables>
   <verificationScript>import static org.assertj.core.api.Assertions.*

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webservice.verification.WSResponseManager

import groovy.json.JsonSlurper
import internal.GlobalVariable as GlobalVariable

RequestObject request = WSResponseManager.getInstance().getCurrentRequest()

ResponseObject response = WSResponseManager.getInstance().getCurrentResponse()

GlobalVariable.API_USER_ID = WS.getElementPropertyValue(response, 'id')</verificationScript>
   <wsdlAddress></wsdlAddress>
</WebServiceRequestEntity>
