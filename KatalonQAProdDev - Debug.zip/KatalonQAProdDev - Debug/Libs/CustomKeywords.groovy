
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import java.lang.String



def static "com.customKeywords.loyaltyIT.CustomKeywords.randString"(
    	int length	) {
    (new com.customKeywords.loyaltyIT.CustomKeywords()).randString(
        	length)
}


def static "com.customKeywords.loyaltyIT.CustomKeywords.generateMFA"() {
    (new com.customKeywords.loyaltyIT.CustomKeywords()).generateMFA()
}


def static "com.customKeywords.loyaltyIT.CustomKeywords.decryptPass"() {
    (new com.customKeywords.loyaltyIT.CustomKeywords()).decryptPass()
}


def static "com.customKeywords.loyaltyIT.CustomKeywords.encryptPass"() {
    (new com.customKeywords.loyaltyIT.CustomKeywords()).encryptPass()
}


def static "com.customKeywords.loyaltyIT.CustomKeywords.generateNewUserMFA"(
    	String apiNewUserMfa	) {
    (new com.customKeywords.loyaltyIT.CustomKeywords()).generateNewUserMFA(
        	apiNewUserMfa)
}


def static "com.testwithhari.katalon.plugins.Gmail.deleteAllEMails"(
    	String emailID	
     , 	String password	
     , 	String folderLableName	) {
    (new com.testwithhari.katalon.plugins.Gmail()).deleteAllEMails(
        	emailID
         , 	password
         , 	folderLableName)
}


def static "com.testwithhari.katalon.plugins.Gmail.sendEmail"(
    	String from_emailaddress	
     , 	String email_password	
     , 	String to_emailaddress	
     , 	String email_subject	
     , 	String email_body	) {
    (new com.testwithhari.katalon.plugins.Gmail()).sendEmail(
        	from_emailaddress
         , 	email_password
         , 	to_emailaddress
         , 	email_subject
         , 	email_body)
}


def static "com.testwithhari.katalon.plugins.Gmail.getEmailsCount"(
    	String emailID	
     , 	String password	
     , 	String folderLableName	) {
    (new com.testwithhari.katalon.plugins.Gmail()).getEmailsCount(
        	emailID
         , 	password
         , 	folderLableName)
}


def static "com.testwithhari.katalon.plugins.Gmail.readLatestEMailBodyContent"(
    	String emailID	
     , 	String password	
     , 	String folderLableName	) {
    (new com.testwithhari.katalon.plugins.Gmail()).readLatestEMailBodyContent(
        	emailID
         , 	password
         , 	folderLableName)
}
