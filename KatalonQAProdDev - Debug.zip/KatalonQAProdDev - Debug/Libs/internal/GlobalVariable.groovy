package internal

import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.main.TestCaseMain


/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */
public class GlobalVariable {
     
    /**
     * <p>Profile default : Link to LIT Portal UI on DEV environment</p>
     */
    public static Object LIT_PORTAL_URL
     
    /**
     * <p></p>
     */
    public static Object USERNAME_ADMIN
     
    /**
     * <p></p>
     */
    public static Object PASSWORD_ADMIN
     
    /**
     * <p>Profile default : API endpoint for DEV</p>
     */
    public static Object API_LIT
     
    /**
     * <p>Profile default : Secret key for Katalon test account</p>
     */
    public static Object SECRETKEY
     
    /**
     * <p></p>
     */
    public static Object EMAILADDRESS
     
    /**
     * <p></p>
     */
    public static Object EFFECTIVE_DATE
     
    /**
     * <p></p>
     */
    public static Object API_SESSION
     
    /**
     * <p></p>
     */
    public static Object MFA
     
    /**
     * <p></p>
     */
    public static Object API_TOKEN
     
    /**
     * <p></p>
     */
    public static Object API_RESP
     
    /**
     * <p></p>
     */
    public static Object API_USER_ID
     
    /**
     * <p></p>
     */
    public static Object API_NEWUSER_TOKEN
     
    /**
     * <p></p>
     */
    public static Object API_NEWUSER_MFA
     
    /**
     * <p></p>
     */
    public static Object API_NEWUSER_MFA_CODE
     
    /**
     * <p>Profile default : DEV URL for setting up new user</p>
     */
    public static Object ACCOUNT_LINK
     
    /**
     * <p>Profile default : DEV link to reset new user password</p>
     */
    public static Object ACCOUNT_LINK_RESET
     

    static {
        try {
            def selectedVariables = TestCaseMain.getGlobalVariables("default")
			selectedVariables += TestCaseMain.getGlobalVariables(RunConfiguration.getExecutionProfile())
            selectedVariables += TestCaseMain.getParsedValues(RunConfiguration.getOverridingParameters(), selectedVariables)
    
            LIT_PORTAL_URL = selectedVariables['LIT_PORTAL_URL']
            USERNAME_ADMIN = selectedVariables['USERNAME_ADMIN']
            PASSWORD_ADMIN = selectedVariables['PASSWORD_ADMIN']
            API_LIT = selectedVariables['API_LIT']
            SECRETKEY = selectedVariables['SECRETKEY']
            EMAILADDRESS = selectedVariables['EMAILADDRESS']
            EFFECTIVE_DATE = selectedVariables['EFFECTIVE_DATE']
            API_SESSION = selectedVariables['API_SESSION']
            MFA = selectedVariables['MFA']
            API_TOKEN = selectedVariables['API_TOKEN']
            API_RESP = selectedVariables['API_RESP']
            API_USER_ID = selectedVariables['API_USER_ID']
            API_NEWUSER_TOKEN = selectedVariables['API_NEWUSER_TOKEN']
            API_NEWUSER_MFA = selectedVariables['API_NEWUSER_MFA']
            API_NEWUSER_MFA_CODE = selectedVariables['API_NEWUSER_MFA_CODE']
            ACCOUNT_LINK = selectedVariables['ACCOUNT_LINK']
            ACCOUNT_LINK_RESET = selectedVariables['ACCOUNT_LINK_RESET']
            
        } catch (Exception e) {
            TestCaseMain.logGlobalVariableError(e)
        }
    }
}
