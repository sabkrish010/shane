import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

//call test case to setup and activate shane's account
WebUI.callTestCase(findTestCase('API/UserManagement/API-CreateUser-E2E'), [:], FailureHandling.STOP_ON_FAILURE)

//navigate to login page
WebUI.openBrowser('')

WebUI.waitForPageLoad(20)

WebUI.navigateToUrl(GlobalVariable.LIT_PORTAL_URL)

WebUI.waitForElementClickable(findTestObject('Page_LIT.Portal.UI/btn-resetPassword'), 20)

//click reset password
WebUI.click(findTestObject('Page_LIT.Portal.UI/btn-resetPassword'))

WebUI.verifyElementVisible(findTestObject('Portal_UI_ResetPassword/h-resetYourPassword'))

WebUI.setText(findTestObject('Portal_UI_ResetPassword/txt-resetPassword'), 'shane@loyaltyit.com')

WebUI.click(findTestObject('Portal_UI_ResetPassword/h-resetYourPassword'))

WebUI.click(findTestObject('Portal_UI_ResetPassword/btn-resetPassword'))

//launch link to set new password
WebUI.navigateToUrl(GlobalVariable.ACCOUNT_LINK_RESET)

WebUI.verifyElementVisible(findTestObject('Portal_UI_CreatePassword/h_createNewPassword'))

password = CustomKeywords.'com.customKeywords.loyaltyIT.CustomKeywords.decryptPass'()

WebUI.setText(findTestObject('Portal_UI_CreatePassword/txt-password'), password)

WebUI.setText(findTestObject('Portal_UI_CreatePassword/txt-confirmPassword'), password)

WebUI.click(findTestObject('Portal_UI_CreatePassword/h_createNewPassword'))

WebUI.click(findTestObject('Portal_UI_CreatePassword/btn-createPassword'))

WebUI.verifyElementText(findTestObject('Portal_UI_ResetPassword/tst-passwordResetSuccessfully'), 'Your password has been reset successfully. Please, enter your credentials to log in.')

//login with new password
WebUI.verifyElementVisible(findTestObject('Page_LIT.Portal.UI/img-litlogo'))

WebUI.setText(findTestObject('Page_LIT.Portal.UI/txt-email'), 'shane@loyaltyit.com')

WebUI.setText(findTestObject('Page_LIT.Portal.UI/txt-password'), password)

WebUI.click(findTestObject('Page_LIT.Portal.UI/lbl-text-password'))

WebUI.click(findTestObject('Page_LIT.Portal.UI/btn-login'))

WebUI.delay(25)

//generate and enter mfa
mfa = CustomKeywords.'com.customKeywords.loyaltyIT.CustomKeywords.generateNewUserMFA'(GlobalVariable.API_NEWUSER_MFA)

WebUI.sendKeys(findTestObject('AuthCode_LIT.Portal.UI/txt-authCode'), mfa)

WebUI.enhancedClick(findTestObject('AuthCode_LIT.Portal.UI/sh-authenticatorCode'))

WebUI.enhancedClick(findTestObject('AuthCode_LIT.Portal.UI/btn_login'))

WebUI.verifyElementVisible(findTestObject('Page_Home/h_welcome'))

WebUI.closeBrowser()

