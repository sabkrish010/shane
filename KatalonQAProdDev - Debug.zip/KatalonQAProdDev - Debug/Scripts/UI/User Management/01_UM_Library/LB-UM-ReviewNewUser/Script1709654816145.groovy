import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

GlobalVariable.EMAILADDRESS = (CustomKeywords.'com.customKeywords.loyaltyIT.CustomKeywords.randString'(12) + '@email.com')

WebUI.setText(findTestObject('NewUser_ReviewPage/Page_Users/txt-email'), GlobalVariable.EMAILADDRESS)

WebUI.setText(findTestObject('NewUser_ReviewPage/Page_Users/txt-phoneNumber'), '+555 81295799')

WebUI.setText(findTestObject('NewUser_ReviewPage/Page_Users/txt-firstName'), 'Jane')

WebUI.setText(findTestObject('NewUser_ReviewPage/Page_Users/txt-lastName'), 'Doe')

WebUI.setText(findTestObject('NewUser_ReviewPage/Page_Users/txt-company'), 'Stark Enterprises')

WebUI.setText(findTestObject('NewUser_ReviewPage/Page_Users/txt-jobTitle'), 'CEO')

WebUI.scrollToElement(findTestObject('NewUser_ReviewPage/Page_Users/txt-calendar'), 5)

//set effective date for 4 days in the future
Date todaysDate = new Date()

GlobalVariable.EFFECTIVE_DATE = todaysDate.plus(4).format('MM/dd/yyyy')

WebUI.delay(5)

datePicker = WebUI.findWebElement(findTestObject('NewUser_ReviewPage/Page_Users/txt-calendar'), 5)

WebUI.executeJavaScript(('arguments[0].value = \'' + GlobalVariable.EFFECTIVE_DATE) + '\';', Arrays.asList(datePicker))

WebUI.sendKeys(findTestObject('NewUser_ReviewPage/Page_Users/txt-calendar'), Keys.chord(Keys.ENTER))

//select time zone
WebUI.selectOptionByIndex(findTestObject('NewUser_ReviewPage/Page_Users/dd-timeZone'), 4)

//select language
WebUI.selectOptionByLabel(findTestObject('NewUser_ReviewPage/Page_Users/dd-language'), 'English', false)

WebUI.enhancedClick(findTestObject('NewUser_ReviewPage/Page_Users/btn-next'))

//validate values entered match
WebUI.verifyElementText(findTestObject('NewUser_ReviewPage/lbl-emailAddress'), GlobalVariable.EMAILADDRESS)

WebUI.verifyElementText(findTestObject('NewUser_ReviewPage/lbl-phoneNumber'), '+555 81295799')

WebUI.verifyElementText(findTestObject('NewUser_ReviewPage/lbl-firstName'), 'Jane')

WebUI.verifyElementText(findTestObject('NewUser_ReviewPage/lbl-lastName'), 'Doe')

WebUI.verifyElementText(findTestObject('NewUser_ReviewPage/lbl-company'), 'Stark Enterprises')

WebUI.verifyElementText(findTestObject('NewUser_ReviewPage/lbl-jobTitle'), 'CEO')

def text = WebUI.getText(findTestObject('NewUser_ReviewPage/lbl-effectiveDate'))

WebUI.verifyMatch(text, '.*/2024.*', true, FailureHandling.STOP_ON_FAILURE)

WebUI.verifyElementText(findTestObject('NewUser_ReviewPage/lbl-language'), 'English')

WebUI.verifyElementText(findTestObject('NewUser_ReviewPage/lbl-timeZone'), '(UTC-09:00) Alaska')

WebUI.scrollToElement(findTestObject('NewUser_ReviewPage/btn-createUser'), 5)

