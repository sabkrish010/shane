import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WS.delay(35)

//call test case to setup and activate shane's account
WebUI.callTestCase(findTestCase('API/UserManagement/API-CreateUser-E2E'), [:], FailureHandling.STOP_ON_FAILURE)

//call endpoint to reset password
WS.sendRequestAndVerify(findTestObject('API/Auth/AUTH_ForgotPassword'))

//validate user's code
WS.sendRequestAndVerify(findTestObject('API/Auth/AUTH_ValidateCode'))

//set new password
password = CustomKeywords.'com.customKeywords.loyaltyIT.CustomKeywords.decryptPass'()

//set new password
resetPasswordResponse = WS.sendRequestAndVerify(findTestObject('API/Auth/AUTH_ResetPassword', [('password') : password, ('confirmPassword') : password, ('email') : 'shane@loyaltyit.com']))

//wait for new MFA to generate
WS.delay(35)

//login with new user's details
WS.sendRequestAndVerify(findTestObject('API/Auth/AUTH_POST_Authenticate', [('email') : 'shane@loyaltyit.com', ('password') : password]))

//generate mfa code
code = CustomKeywords.'com.customKeywords.loyaltyIT.CustomKeywords.generateNewUserMFA'(GlobalVariable.API_NEWUSER_MFA)

//authenticate with mfa
WS.sendRequestAndVerify(findTestObject('API/Auth/AUTH_POST_Authenticate_Mfa', [('session') : GlobalVariable.API_SESSION, ('code') : code
            , ('email') : 'shane@loyaltyit.com']))

