import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

//only authenticate if no API Token exists
if (GlobalVariable.API_TOKEN == '') {
    WebUI.callTestCase(findTestCase('API/Authentication/API-Auth'), [:], FailureHandling.STOP_ON_FAILURE)
}

//create email address
GlobalVariable.EMAILADDRESS = (CustomKeywords.'com.customKeywords.loyaltyIT.CustomKeywords.randString'(12) + '@email.com')

//create past effective date
Date todaysDate = new Date()

GlobalVariable.EFFECTIVE_DATE = todaysDate.minus(4).format('yyyy-MM-dd')

//create new user
createUserResponse = WS.sendRequestAndVerify(findTestObject('API/UserManagement/UM_POST_CreateUser', [('email') : GlobalVariable.EMAILADDRESS
            , ('phone') : '523453456345632656', ('firstName') : 'Shane', ('lastName') : 'Loftus', ('company') : 'LIT', ('jobTitle') : 'Director'
            , ('effectiveDate') : GlobalVariable.EFFECTIVE_DATE]))

//Verify response returns the 201 status code'
WS.verifyResponseStatusCode(createUserResponse, 400)