import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

//only authenticate if no API Token exists
if (GlobalVariable.API_TOKEN == '') {
    WebUI.callTestCase(findTestCase('API/Authentication/API-Auth'), [:], FailureHandling.STOP_ON_FAILURE)
}

//get global variable to an ID that doe not exist
GlobalVariable.API_USER_ID = '0dbd971d-c1ac-4fbe-edfc-9cdb1cceb9b0'

//execute get by id for non-existent user
getUserById = WS.sendRequestAndVerify(findTestObject('API/UserManagement/UM_GetUser_ById'))

//Verify response returns a 404 status code
WS.verifyResponseStatusCode(getUserById, 404)


//store error detail from API response
errorDetail = WS.getElementPropertyValue(getUserById, 'detail')

//verify error detail matches the one expected
WS.verifyEqual(errorDetail, 'User not found for this identifier')

