import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

//only authenticate if no API Token exists
if (GlobalVariable.API_TOKEN == '') {
    WebUI.callTestCase(findTestCase('API/Authentication/API-Auth'), [:], FailureHandling.STOP_ON_FAILURE)
}

GlobalVariable.EMAILADDRESS = (CustomKeywords.'com.customKeywords.loyaltyIT.CustomKeywords.randString'(12) + '@email.com')

Date todaysDate = new Date()

GlobalVariable.EFFECTIVE_DATE = todaysDate.plus(4).format('yyyy-MM-dd')

def createUserResponse = WS.sendRequestAndVerify(findTestObject('API/UserManagement/UM_POST_CreateUser', [('email') : GlobalVariable.EMAILADDRESS
            , ('phone') : phone, ('firstName') : firstName, ('lastName') : lastName, ('company') : company, ('jobTitle') : jobTitle
            , ('language') : language, ('effectiveDate') : GlobalVariable.EFFECTIVE_DATE, ('timezone') : timezone]))

//Verify response returns the 201 status code'
WS.verifyResponseStatusCode(createUserResponse, 201)

//execute get use by id request and store response
getUserByIdResponse = WS.sendRequestAndVerify(findTestObject('API/UserManagement/UM_GetUser_ById'))

//Verify response returns a 200 status code'
WS.verifyResponseStatusCode(getUserByIdResponse, 200)

//store user id from API response
userId = WS.getElementPropertyValue(getUserByIdResponse, 'id')

//verify user id matches the id searched
WS.verifyEqual(userId, GlobalVariable.API_USER_ID)

//store email from API response
emailAddr = WS.getElementPropertyValue(getUserByIdResponse, 'email')

//make email lowercase for comparison
lowerEmail = GlobalVariable.EMAILADDRESS.toLowerCase()

//verify email matches the one created
WS.verifyEqual(emailAddr, lowerEmail)

//store phone from API response
phoneNum = WS.getElementPropertyValue(getUserByIdResponse, 'phone')

//verify phone matches the one created
WS.verifyEqual(phoneNum, phone)

//store first name from API response
fName = WS.getElementPropertyValue(getUserByIdResponse, 'firstName')

//verify first name matches the one created
WS.verifyEqual(fName, firstName)

//store last name from API response
lName = WS.getElementPropertyValue(getUserByIdResponse, 'lastName')

//verify last name matches the one created
WS.verifyEqual(lName, lastName)

//store company from API response
comp = WS.getElementPropertyValue(getUserByIdResponse, 'company')

//verify company matches the one created
WS.verifyEqual(comp, company)

//store job title from API response
jTitle = WS.getElementPropertyValue(getUserByIdResponse, 'jobTitle')

//verify job title matches the one created
WS.verifyEqual(jTitle, jobTitle)

//store status from API response
status = WS.getElementPropertyValue(getUserByIdResponse, 'status')

//verify status matches the one created
WS.verifyEqual(status, 'Inactive')

//store language from API response
lang = WS.getElementPropertyValue(getUserByIdResponse, 'language')

//verify status matches the one created
WS.verifyEqual(lang, language)

//store time xone from API response
timeZone = WS.getElementPropertyValue(getUserByIdResponse, 'timezone')

//verify status matches the one created
WS.verifyEqual(timeZone, timezone)
