package com.customKeywords.loyaltyIT

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows

import internal.GlobalVariable

import de.taimos.totp.TOTP
import org.apache.commons.codec.binary.Base32
import org.apache.commons.codec.binary.Hex
import com.kms.katalon.util.CryptoUtil

public class CustomKeywords {

	//	 Generate a random string of specified length

	@Keyword
	def randString(int length) {
		String s1 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
		Random rand = new Random()
		StringBuilder randomString = new StringBuilder()

		for (int j=1;j<=length;j++) {
			randomString.append(s1.charAt(rand.nextInt(s1.length())))
		}
		return randomString.toString();
	}

	//    Generate MFA
	@Keyword
	def generateMFA() {
		def decryptedText = (CryptoUtil.decode(CryptoUtil.getDefault(GlobalVariable.SECRETKEY)))

		Base32 base32 = new Base32()

		byte[] bytes = base32.decode(decryptedText)

		String hexKey = Hex.encodeHexString(bytes)

		String code = TOTP.getOTP(hexKey)

		return code.toString()
	}

	//    Decrypt password
	@Keyword
	def decryptPass() {
		def decryptedText = (CryptoUtil.decode(CryptoUtil.getDefault(GlobalVariable.PASSWORD_ADMIN)))
		return decryptedText.toString()
	}

	//    Encrypt password
	@Keyword
	def encryptPass() {
		def encryptedText = (CryptoUtil.encode(CryptoUtil.getDefault(GlobalVariable.PASSWORD_ADMIN)))
		return encryptedText.toString()
	}

	//    Generate new user's MFA
	@Keyword
	def generateNewUserMFA(String apiNewUserMfa) {
		def decryptedText = apiNewUserMfa == "" ? GlobalVariable.API_NEWUSER_MFA: apiNewUserMfa

		Base32 base32 = new Base32()

		byte[] bytes = base32.decode(apiNewUserMfa)

		String hexKey = Hex.encodeHexString(bytes)

		String code = TOTP.getOTP(hexKey)

		return code.toString()
	}
}
